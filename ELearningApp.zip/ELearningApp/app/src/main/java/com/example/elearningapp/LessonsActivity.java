package com.example.elearningapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LessonsActivity extends AppCompatActivity {

    private int progress = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lessons);

        TextView tvProgress = findViewById(R.id.tvProgress);
        ProgressBar progressBar = findViewById(R.id.progressBar);

        Button btnLesson1 = findViewById(R.id.btnLesson1);
        Button btnLesson2 = findViewById(R.id.btnLesson2);
        Button btnLesson3 = findViewById(R.id.btnLesson3);
        Button btnComplete = findViewById(R.id.btnComplete);

        btnLesson1.setOnClickListener(v ->
                Toast.makeText(this,
                        "Watching Lesson 1",
                        Toast.LENGTH_SHORT).show());

        btnLesson2.setOnClickListener(v ->
                Toast.makeText(this,
                        "Watching Lesson 2",
                        Toast.LENGTH_SHORT).show());

        btnLesson3.setOnClickListener(v ->
                Toast.makeText(this,
                        "Watching Lesson 3",
                        Toast.LENGTH_SHORT).show());

        btnComplete.setOnClickListener(v -> {
            if (progress < 100) {
                progress += 33;

                if (progress > 100) {
                    progress = 100;
                }

                progressBar.setProgress(progress);
                tvProgress.setText("Progress: " + progress + "%");

                Toast.makeText(this,
                        "Lesson Completed",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}