package com.example.elearningapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Button btnFeatured = findViewById(R.id.btnFeatured);
        Button btnPopular = findViewById(R.id.btnPopular);
        Button btnDashboard = findViewById(R.id.btnDashboard);
        Button btnProfile = findViewById(R.id.btnProfile);
        Button btnLogout = findViewById(R.id.btnLogout);

        btnFeatured.setOnClickListener(v ->
                startActivity(new Intent(this,
                        CourseDetailsActivity.class)));

        btnPopular.setOnClickListener(v ->
                startActivity(new Intent(this,
                        CourseDetailsActivity.class)));

        btnDashboard.setOnClickListener(v ->
                startActivity(new Intent(this,
                        DashboardActivity.class)));

        btnProfile.setOnClickListener(v ->
                startActivity(new Intent(this,
                        ProfileActivity.class)));

        btnLogout.setOnClickListener(v -> {
            Intent intent = new Intent(this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                    Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        });
    }
}