package com.example.elearningapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CourseDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_details);

        Button btnEnroll = findViewById(R.id.btnEnroll);

        btnEnroll.setOnClickListener(v -> {
            Toast.makeText(this,
                    "Course Enrolled Successfully",
                    Toast.LENGTH_SHORT).show();

            startActivity(new Intent(
                    CourseDetailsActivity.this,
                    LessonsActivity.class));
        });
    }
}