package com.example.elearningapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        Button btnContinue = findViewById(R.id.btnContinue);
        Button btnUpdateProfile = findViewById(R.id.btnUpdateProfile);

        btnContinue.setOnClickListener(v ->
                startActivity(new Intent(
                        DashboardActivity.this,
                        LessonsActivity.class)));

        btnUpdateProfile.setOnClickListener(v ->
                startActivity(new Intent(
                        DashboardActivity.this,
                        ProfileActivity.class)));
    }
}