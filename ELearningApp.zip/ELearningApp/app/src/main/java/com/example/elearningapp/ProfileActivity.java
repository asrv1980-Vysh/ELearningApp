package com.example.elearningapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        EditText etName = findViewById(R.id.etProfileName);
        EditText etEmail = findViewById(R.id.etProfileEmail);

        Button btnSave = findViewById(R.id.btnSaveProfile);
        Button btnDashboard = findViewById(R.id.btnBackDashboard);

        btnSave.setOnClickListener(v -> {

            String name = etName.getText().toString().trim();
            String email = etEmail.getText().toString().trim();

            if (name.isEmpty() || email.isEmpty()) {
                Toast.makeText(this,
                        "Please enter all details",
                        Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this,
                        "Profile Updated Successfully",
                        Toast.LENGTH_SHORT).show();
            }
        });

        btnDashboard.setOnClickListener(v ->
                startActivity(new Intent(
                        ProfileActivity.this,
                        DashboardActivity.class)));
    }
}